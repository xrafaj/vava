package com.application.frontend_.model;

public class Users {
    public String email;
    public String password;

    public Users(String user) {
    }

    public void setEmail() {
        this.email = email;
    }

    public void setPassword() {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
